$ErrorActionPreference = "Stop"

if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) {
	throw "LOCALAPPDATA is not set."
}

$SourceBinary = Join-Path $PSScriptRoot "unio.exe"
$InstallDir = Join-Path $env:LOCALAPPDATA "Unio\bin"
$TargetBinary = Join-Path $InstallDir "unio.exe"

function Test-PathContains {
	param(
		[string]$PathValue,
		[string]$Candidate
	)

	$NormalizedCandidate = [System.IO.Path]::GetFullPath($Candidate).TrimEnd("\")
	foreach ($Entry in ($PathValue -split ";")) {
		if ([string]::IsNullOrWhiteSpace($Entry)) {
			continue
		}

		$ExpandedEntry = [Environment]::ExpandEnvironmentVariables($Entry.Trim().Trim('"'))
		try {
			$NormalizedEntry = [System.IO.Path]::GetFullPath($ExpandedEntry).TrimEnd("\")
		}
		catch {
			continue
		}

		if ($NormalizedEntry -ieq $NormalizedCandidate) {
			return $true
		}
	}

	return $false
}

if (-not (Test-Path -LiteralPath $SourceBinary -PathType Leaf)) {
	throw "Run install.ps1 from the extracted Unio archive."
}

New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
Copy-Item -LiteralPath $SourceBinary -Destination $TargetBinary -Force
Write-Host "Installed Unio to $TargetBinary."

$UserPath = [Environment]::GetEnvironmentVariable("Path", "User")
if (-not (Test-PathContains -PathValue $UserPath -Candidate $InstallDir)) {
	if ([string]::IsNullOrWhiteSpace($UserPath)) {
		$NewUserPath = $InstallDir
	}
	else {
		$NewUserPath = $UserPath.TrimEnd(";") + ";" + $InstallDir
	}
	[Environment]::SetEnvironmentVariable("Path", $NewUserPath, "User")
	Write-Host "Added $InstallDir to the user PATH."
}
else {
	Write-Host "$InstallDir is already on the user PATH."
}

if (-not (Test-PathContains -PathValue $env:Path -Candidate $InstallDir)) {
	$env:Path = $env:Path.TrimEnd(";") + ";" + $InstallDir
}

Write-Host "Run 'unio' in this PowerShell session or open a new terminal."
